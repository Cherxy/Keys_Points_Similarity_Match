"""kornia.feature.disk"""

from .disk import DISK
